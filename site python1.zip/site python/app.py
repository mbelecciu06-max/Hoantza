import os
from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = "super-secret-key"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["GET", "POST"])
def chat():
    if "username" not in session:
        return redirect("/login")
        
    users = list(session.get("acive_users", []))
    if session["username"] not in users:
        users.append(session["username"])
        session["acive-users"] = users

    if request.method == "POST":
        message = request.form["message"]
        username = session["username"]

        with open("messages.txt", "a", encoding="utf-8") as f:
            f.write(f"{username}: {message}\n")

        return redirect("/chat")

    messages = []  
    try:
        with open("messages.txt", "r", encoding="utf-8") as f:
            messages = f.readlines()
    except FileNotFoundError:
        pass
    return render_template("chat.html", messages=messages)

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        session["username"] = username
        return redirect("/chat")

    return render_template("login.html")

@app.route("/clear", methods=["POST"])
def clear():
     if "username" in session and session["username"] == "admin":
        open("messages.txt", "w").close()
     return redirect("/chat")


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("username", None)
    return redirect("/login")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)